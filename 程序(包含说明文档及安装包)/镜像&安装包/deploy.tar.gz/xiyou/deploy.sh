pip install virtualenv
virtualenv venv --python=python2.7
. venv/bin/activate
pip install -r requirements.txt
python manage.py runserver 0.0.0.0:8010
