# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import logging

from celery.task import task
from django.db import models
from docker_image import Docker
from const import STATUS_CHOICES, Status
from utils import get_pod_instance
import pytz
from datetime import datetime

logger = logging.getLogger('app')

# 配置表
from deploy.model.k8s_cluster import K8sCluster

K8S_CONNECTION_TIMEOUT = 5


class Config(models.Model):
    name = models.CharField(max_length=60)


# 项目表
class Project(models.Model):
    project_id = models.AutoField(u'项目id', primary_key=True)
    project_name = models.CharField(u'项目名称', max_length=60)
    git_ssh_address = models.CharField(u'git ssh地址', max_length=255)
    git_alias = models.CharField(u'git别名', max_length=60, default='')
    dir_address = models.CharField(u'项目路径地址', max_length=160)
    is_cluster = models.SmallIntegerField(u'是否集群模式', default=0)
    describe = models.CharField(u'描述', max_length=255)
    create_time = models.DateTimeField(u'创建时间', auto_now_add=True, null=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)


# 集群相关
class Cluster(models.Model):
    cluster_id = models.AutoField(u'集群id', primary_key=True)
    cluster_name = models.CharField(max_length=200, unique=True, verbose_name='集群名称')
    describe = models.TextField(
        default='', null=True, blank=True, verbose_name='描述信息')
    visit_by_https = models.BooleanField(
        default=False, verbose_name='是否支持https访问')
    user_name = models.CharField(
        max_length=200, blank=True, null=True, default='', verbose_name='https用户名')
    password = models.CharField(
        max_length=200, blank=True, null=True, default='', verbose_name='https密码')
    api_server = models.CharField(
        max_length=200, default='', verbose_name='api 服务地址')
    dns_server = models.CharField(
        max_length=200, default='', verbose_name='dns 服务地址')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    def get_k8s_config(self):
        cluster = {
            "name": self.cluster_name,
            "cluster": {
                "server": self.get_api_server(),
            }
        }
        context = {
            "name": self.cluster_name,
            "context": {
                "cluster": self.cluster_name,
            }
        }
        k8s_config = {
            "current-context": self.cluster_name,
            "contexts": [context, ],
            "clusters": [cluster, ],
        }
        if self.visit_by_https:
            user = {
                "name": self.user_name,
                "user": {
                    "client-certificate-data": self.password,
                    "client-key-data": self.password,
                },
            }
            cluster["cluster"]["certificate-authority-data"] = self.password
            context["context"]["user"] = self.user_name
            k8s_config["users"] = [user, ]
        return k8s_config

    def get_api_server(self):
        if self.visit_by_https and not self.api_server.startswith('https://'):
            return 'https://' + self.api_server
        if not self.visit_by_https and not self.api_server.startswith('http://'):
            return 'http://' + self.api_server
        return self.api_server


# 上线工单表
class Release(models.Model):
    release_id = models.AutoField(u'上线工单id', primary_key=True)
    project_id = models.IntegerField(u'项目id', default=0)
    title = models.CharField(u'标题', max_length=60)
    branch = models.CharField(u'分支', max_length=160)
    version = models.CharField(u'版本', max_length=80)
    exec_command = models.CharField(max_length=2000, default='')
    backup_name = models.CharField(u'备份分支名称(以backup_开头)', max_length=255)
    image_name = models.CharField(max_length=200, default='python')
    cluster = models.ForeignKey(
        Cluster, null=True, on_delete=models.SET_NULL, related_name="job")
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default=Status.READY)
    port = models.IntegerField(default=8080)
    create_time = models.DateTimeField(u'创建时间', auto_now_add=True, null=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)
    docker_build_logs = models.TextField(default='')
    k8s_logs = models.TextField(default='')

    def list_all_pod(self):
        k8s_cluster = K8sCluster(
            "default", customed_config=self.get_k8s_config())
        pod_list = k8s_cluster.v1client.list_pod_for_all_namespaces(
            _request_timeout=K8S_CONNECTION_TIMEOUT)
        return get_pod_instance(pod_list.items)

    def get_k8s_config(self):
        cluster = Cluster.objects.filter(cluster_id=self.cluster_id).first()
        return cluster.get_k8s_config()

    # 异步启动
    def start(self):
        print ("start")
        res = runJob.delay(self.release_id)
        print res.traceback

    def stop(self):
        k8s_cluster = K8sCluster(
            "default", customed_config=self.get_k8s_config())
        self.status = Status.DESTROYED
        self.save(update_fields=['status'])
        res = k8s_cluster.delete_deployment_by_name(self.title)
        return res

    def list_all_pods(self):
        label_dict = {
            'app': str(self.release_id) + self.title,
        }
        k8s_cluster = K8sCluster(
            "default", customed_config=self.get_k8s_config())
        return get_pod_instance(k8s_cluster.get_pods(label_dict))


@task(bind=True)
def runJob(self, release_id):
    print "runJob"
    release = Release.objects.filter(release_id=release_id).first()
    project = Project.objects.filter(project_id=release.project_id).first()
    try:
        release.status = Status.IMAGEBUILDING
        release.save(update_fields=['status'])
        image_name = Docker().get_image(release, project)
        release.status = Status.PENDING
        release.save(update_fields=['status'])
        k8s_cluster = K8sCluster(
            "default", customed_config=release.get_k8s_config())
        print "release.get_k8s_config()" , release.get_k8s_config()
        res = k8s_cluster.create_deployment(release.release_id, release.title, project.project_name,image_name,
                                            release.port,
                                            release.port,
                                            release.exec_command,release.logs,release.end_at)
        print "k8s execute result",res
        release.k8s_logs = res
        release.status = Status.RUNNING
        release.save(update_fields=['status'])
        release.save(update_fields=['k8s_logs'])
    except Exception as e:
        release.status = Status.FAIL
        release.save(update_fields=['logs', 'status', 'end_at'])


def get_pod_instance(pod_list):
    pod_instance_list = []
    for pod in pod_list:
        # assert False, pod
        if isinstance(pod, dict):
            instance = {
                "pod_name": pod['metadata']['name'],
                "pod_ip": (pod['status']).get('podIP', ''),
                "host": "%s/%s" % ((pod['spec']).get('nodeName', ''), (pod['status']).get('hostIP', '')),
                "phase": get_pod_container_status(pod['status']),
                "last_phase": get_pod_container_status(pod['status'], 'lastState', 'finishedAt'),
                "containers": get_container(pod['status']['containerStatuses']) if pod['status'].has_key(
                    'containerStatuses') else '',
                "start_time": (pod['status']).get('startTime', ''),
                "namespace": pod['metadata']['namespace']
            }
        else:
            instance = {
                "pod_name": pod.metadata.name,
                "pod_ip": pod.status.pod_ip,
                "host": "%s/%s" % (pod.spec.node_name, pod.status.host_ip),
                "phase": get_pod_container_status_py(pod.status),
                "last_phase": get_pod_container_status_py(pod.status, 'last_state', 'finished_at'),
                "containers": get_container(pod.status.container_statuses),
                "start_time": pod.status.start_time,
                "namespace": pod.metadata.namespace
            }
        pod_instance_list.append(instance)
    return pod_instance_list


def get_pod_container_status(pod_status, option='state', param='startedAt'):
    phase = {}
    if option == 'state':
        phase['status'] = pod_status['phase']
    for condition in pod_status['conditions'] if pod_status.has_key('conditions') else []:
        if condition['type'] == 'PodScheduled' and condition['status'] == 'False':
            phase['reason'] = condition['reason']
            return phase
        else:
            break
    container_statuses = pod_status[
        'containerStatuses'] if pod_status.has_key('containerStatuses') else []
    for index, container_status in enumerate(container_statuses):
        for key, values in container_status[option].items():
            if key == 'running':
                phase['timestamp'] = utc_to_local(
                    values[param]) if values.has_key(param) else ''
            else:
                phase['timestamp'] = utc_to_local(
                    values[param]) if values.has_key(param) else ''
                phase['reason'] = values[
                    'reason'] if values.has_key('reason') else ''
    return phase


def get_host_list(node_list):
    host_list = []
    for node in node_list:
        host = {
            "name": node.metadata.name,
            "ip": node.status.addresses[0].address,
            "cpu": node.status.allocatable['cpu'],
            'gpu': node.status.allocatable['nvidia.com/gpu'] if 'nvidia.com/gpu' in node.status.allocatable else 0,
            "memory": node.status.allocatable['memory'],
            "instance_count": node.status.allocatable['pods'],
            "phase": get_host_status(node),
            'unschedulable': True if node.spec.unschedulable else False
        }
        host_list.append(host)
    return host_list


def get_container(container_statuses):
    containers = []
    if container_statuses:
        for container_dict in container_statuses:
            if not isinstance(container_dict, dict):
                container_dict = container_dict.to_dict()
            containers.append({
                "name": container_dict['name'],
                "image": container_dict['image'],
                # "container_id": container_dict['container_id'] if container_dict.has_key('container_id') else container_dict['containerID'],
            })
    return containers


def get_pod_container_status_py(pod_status, option='state', param='started_at'):
    phase = {}
    if option == 'state':
        phase['status'] = pod_status.phase
    for condition in pod_status.conditions if has_effect_attr(pod_status, 'conditions') else []:
        if condition.type == 'PodScheduled' and condition.status == 'False':
            phase['reason'] = condition.reason
            return phase
        else:
            break
    for index, container_status in enumerate(pod_status.container_statuses) if has_effect_attr(pod_status,
                                                                                               'container_statuses') else []:
        for key, value in getattr(container_status, option).__dict__.items() if has_effect_attr(container_status,
                                                                                                option) else {}.items():
            if key.startswith('__'):
                continue
            if key == '_running' and value is not None:
                phase['timestamp'] = utc_to_local(
                    getattr(value, param)) if has_effect_attr(value, param) else ''
            elif value is not None:
                phase['timestamp'] = utc_to_local(
                    getattr(value, param)) if has_effect_attr(value, param) else ''
                phase['reason'] = value.reason if has_effect_attr(
                    value, 'reason') else ''
    return phase


def utc_to_local(utc_time, utc_format='%Y-%m-%dT%H:%M:%SZ'):
    utc_dt = utc_time
    local_tz = pytz.timezone('Asia/Shanghai')
    local_format = "%Y-%m-%d %H:%M:%S"
    if not isinstance(utc_time, datetime):
        utc_dt = datetime.strptime(utc_time, utc_format)
    local_dt = utc_dt.replace(tzinfo=pytz.utc).astimezone(local_tz)
    time_str = local_dt.strftime(local_format)
    return time_str


def has_effect_attr(obj, attr):
    return getattr(obj, attr) is not None if hasattr(obj, attr) else False


def get_host_status(node):
    last_cond = ''
    for con in node.status.conditions:
        if con.status == 'True':
            last_cond = con
            break

    if last_cond:
        return last_cond.type if last_cond.type else ''
    return last_cond
