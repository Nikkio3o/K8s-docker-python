# -*- coding: UTF-8 -*-


# 站点
site = {
    'name' : 'Mogui',
    'name_tips' : '部署系统',
    'title' : '魔鬼部署系统',
    'version' : 'v1.0.0',
    'language_code' : 'zh-Hans',
    'time_zone' : 'Asia/Shanghai'
}


# 视图
view = {
    'version' : 'v1'
}


# 数据库
db = {
    'name' : 'deploy',
    'user' : 'root',
    'pwd'  : 'hanghang',
    'host' : '192.168.56.82',
    'port' : 30001
}


# 分页
page = {
    'page_sizes' : '[10, 30, 60, 100]',
    'page_size' : 10,
    'page_layout' : 'total, sizes, prev, pager, next, jumper'
}

#节点ip
ip = {
    'master' : '192.168.56.80',
    'node1' : '192.168.56.81',
    'node2' : '192.168.56.82'
}