# -*- coding: UTF-8 -*-


from django.shortcuts import render
from django.views.decorators import csrf
from deploy.model.models import Cluster
import time,os
from deploy.common import function,config
from deploy.lib import git
import requests
import json
import requests
import math

def index(request) :
    context = {
        'count' : Cluster.objects.count(),
        'page' : config.page
    }
    return render(request, 'cluster/index.html', context)

def index_node(request) :
    context = {
        'count' : 3,
        'page' : config.page
    }
    return render(request, 'cluster/node.html', context)

def saveinfo(request) :
    # 项目id
    cluster_id = request.GET.get('id', '')
    if len(cluster_id) > 0 :
        # 获取项目数据
        data = Cluster.objects.filter(cluster_id=cluster_id).first()
        if data != None :
            data.describe = data.describe.replace("\n", '\\n')
    else :
        data = None

    context = {
        'cluster_id' : cluster_id,
        'data' : data
    }
    return render(request, 'cluster/saveinfo.html', context)



def get_cluster_list(request) :
    keywords = request.POST.get('keywords', '')
    page = int(request.POST.get('page', 1))-1
    page_size = int(request.POST.get('page_size', config.page['page_size']))
    page_start = page*page_size
    data = Cluster.objects.filter(cluster_name__contains=keywords).all().order_by('-cluster_id').values('cluster_id', 'cluster_name', 'api_server', 'describe', 'create_time')[page_start:page_start+page_size]
    result = []
    for items in data :

        # 日期
        items['create_time'] = items['create_time'].strftime('%Y-%m-%d %H:%M')

        # 追加到列表中
        result.append(items)

    return function.ajax_return_exit('操作成功', 0, result)

def get_service_node_list(request) :


    jsondata = requests.get('https://192.168.56.80:6443/apis/metrics.k8s.io/v1beta1/nodes',verify=False)
#     jsondata = {
#     "kind": "NodeMetricsList",
#     "apiVersion": "metrics.k8s.io/v1beta1",
#     "metadata": {
#         "selfLink": "/apis/metrics.k8s.io/v1beta1/nodes"
#     },
#     "items": [
#         {
#             "metadata": {
#                 "name": "master",
#                 "selfLink": "/apis/metrics.k8s.io/v1beta1/nodes/master",
#                 "creationTimestamp": "2020-05-28T13:36:55Z"
#             },
#             "timestamp": "2020-05-28T12:46:52Z",
#             "window": "30s",
#             "usage": {
#                 "cpu": "432261949n",
#                 "memory": "1048292Ki"
#             }
#         },
#         {
#             "metadata": {
#                 "name": "node1",
#                 "selfLink": "/apis/metrics.k8s.io/v1beta1/nodes/node1",
#                 "creationTimestamp": "2020-05-28T13:36:55Z"
#             },
#             "timestamp": "2020-05-28T13:36:44Z",
#             "window": "30s",
#             "usage": {
#                 "cpu": "204016946n",
#                 "memory": "538224Ki"
#             }
#         },
#         {
#             "metadata": {
#                 "name": "node2",
#                 "selfLink": "/apis/metrics.k8s.io/v1beta1/nodes/node2",
#                 "creationTimestamp": "2020-05-28T13:36:55Z"
#             },
#             "timestamp": "2020-05-28T12:47:00Z",
#             "window": "30s",
#             "usage": {
#                 "cpu": "335726894n",
#                 "memory": "887340Ki"
#             }
#         }
#     ]
# }

    print(jsondata.json())

    dict_all_data = jsondata.json()

    list_items = dict_all_data["items"]
    list_node = []

    for item in list_items:
        dict_node = {}

        dict_node["node_name"] = item["metadata"]["name"]
        if dict_node["node_name"] == "master":
            dict_node["selfLink"] = config.ip['master']
        if dict_node["node_name"] == "node1":
            dict_node["selfLink"] = config.ip['node1']
        if dict_node["node_name"] == "node2":
            dict_node["selfLink"] = config.ip['node2']

        # cpu_data = int(item["usage"]["cpu"].replace("n", ''))
        # dict_node["cpu"] = cpu_data
        # dict_node["memory"] = int(item["usage"]["memory"].replace("Ki",''))
        cpu_data = float(item["usage"]["cpu"].replace("n", ''))
        cpu_use = (cpu_data/(2*1000*1000*1000))*100
        cpu_use = round(cpu_use,2)
        dict_node["cpu"] = math.ceil(cpu_use)
        print("cup_use:",cpu_use,"cpudata=",cpu_data)
        memory_data = float(item["usage"]["memory"].replace("Ki",''))
        if dict_node["node_name"] == "master":
            memory_use = (memory_data/(4*1024*1024))*100
        else:
            memory_use = (memory_data/(2*1024*1024))*100
        memory_use = math.ceil(round(memory_use,2))
        print("memory:",memory_use,"memory_data=",memory_data)
        dict_node["memory"] = memory_use
        list_node.append(dict_node)

    return function.ajax_return_exit('操作成功', 0, list_node)

def save(request) :
    # 项目id
    cluster_id = request.POST.get('cluster_id', '')

    # 等于0则添加
    if len(cluster_id) == 0 :
        # 数据添加
        Cluster(
            cluster_name=request.POST['cluster_name'],
            describe=request.POST['describe'],
            api_server=request.POST['api_server']
        ).save()
    else :
        # 数据更新
        Cluster.objects.filter(cluster_id=cluster_id).update(
            cluster_name=request.POST['cluster_name'],
            describe=request.POST['describe'],
            api_server=request.POST['api_server']
        )

    # 返回数据
    return function.ajax_return_exit('操作成功')




def cluster_delete(request) :
    cluster_id = request.POST.get('cluster_id', '0')
    if cluster_id == '0' :
        return function.ajax_return_exit('参数错误', -1)
    Cluster.objects.filter(cluster_id=cluster_id).delete()

    # 返回数据
    return function.ajax_return_exit('删除成功')