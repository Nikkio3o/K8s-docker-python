# -*- coding: UTF-8 -*-

from django.shortcuts import render
from deploy.common import function,config
import json
import logging
import requests



def index(request) :
    context = {
        'count' : 3,
        'page' : config.page
    }
    return render(request, 'service/index.html', context)


def get_service_list(request) :

    list_service = [{"image_name":"Mysql","desc":"提供了数据库服务"},{"image_name":"Python","desc":"提供python开发环境"},\
                    {"image_name":"Java","desc":"提供Java开发环境"}]


    return function.ajax_return_exit('操作成功', 0, list_service)
