# -*- coding: utf-8 -*-
import logging

from kubernetes import client
from kubernetes import config
from kubernetes.client import Configuration
from kubernetes.client import configuration
from kubernetes.client.rest import ApiException
from kubernetes.config.kube_config import KubeConfigLoader
from kubernetes.stream import stream
from django.conf import settings
import json
import yaml
from jinja2 import PackageLoader, Environment

K8S_CONNECTION_TIMEOUT = 5
DEFAULT_PORT = 17553

logger = logging.getLogger('app')


class Deployment(object):
    def __init__(self, release_id, name, app_name, replicas, image_name, exe_command, container_port, host_port,
                 registry_key,logs,end_at):
        super(Deployment, self).__init__()
        self.release_id = release_id
        self.name = name
        self.app_name = str(release_id) + app_name
        self.replicas = replicas
        self.image_name = image_name
        self.exe_command = exe_command
        self.container_port = container_port
        self.host_port = host_port
        self.registry_key = registry_key
        self.log = logs
        self.end_at = end_at


class K8sCluster(object):
    def __init__(self, namespace, node_labels=None, envs=[], mounts=[], customed_config=None, shm_memory=None):

        super(K8sCluster, self).__init__()
        self.namespace = namespace
        self.load_config(customed_config)
        # self.load_local_config()
        self.v1client = client.CoreV1Api()
        self.v1beta1 = client.ExtensionsV1beta1Api()
        self.v1apps = client.AppsV1Api()
        self.delete_options = client.V1DeleteOptions()
        self.delete_options.propagation_policy = 'Background'
        self.envs = envs
        self.mounts = mounts
        self.node_labels = node_labels
        self.shm_memory = shm_memory
        if not self.namespace_exist():
            self.create_namespace()

    def namespace_exist(self):
        try:
            self.v1client.read_namespace(name=self.namespace, _request_timeout=K8S_CONNECTION_TIMEOUT)
            return True
        except ApiException as e:
            return False

    def load_config(self, customed_config):
        if settings.USE_LOCAL_K8S:
            self.load_local_config()
        else:
            self.load_remote_config(customed_config)

    def load_local_config(self):
        config.load_kube_config()
        c = Configuration()
        c.assert_hostname = False
        Configuration.set_default(c)

    def load_remote_config(self, customed_config):
        # conf = type.__call__(Configuration)
        conf = Configuration()
        KubeConfigLoader(config_dict=customed_config).load_and_set(conf)
        Configuration.set_default(conf)

    def create_namespace(self):
        body = {
            'kind': 'Namespace',
            'metadata': {
                'name': self.namespace
            },
            'labels': {
                'name': self.namespace
            }
        }
        resp = self.v1client.create_namespace(body=body, _request_timeout=K8S_CONNECTION_TIMEOUT)
        logger.info('Create namespace %s successed!' % self.namespace)
        return resp

    def create_pod(self, pod_name, labels, container_name, image, port, args, restart_policy):
        pod_body = self.get_pod_template(image, labels, container_name, port, args, restart_policy)
        pod_body['apiVersion'] = 'v1'
        pod_body['kind'] = 'Pod'
        pod_body['metadata']['name'] = pod_name
        js = json.dumps(pod_body)
        print(js)
        resp = self.v1client.create_namespaced_pod(namespace=self.namespace, body=pod_body,
                                                   _request_timeout=K8S_CONNECTION_TIMEOUT)
        logger.info('Create pod %s successed!' % pod_name)
        return resp

    def get_pod_template(self, image, labels, container_name, args, port, restart_policy='Always'):
        pod_template = {
            'metadata': {
                'labels': labels
            },
            'spec': {
                'containers': [{
                    'name': container_name,
                    'image': image,
                    'command': ["/bin/bash", "-c"],
                    'args': args,
                    'imagePullPolicy': 'Always',
                    'ports': [{'containerPort': port}]
                }],
                'restartPolicy': restart_policy,
            }
        }
        return pod_template

    def create_deployment(self, release_id, deploy_name, app_name, container_port, host_port, command,release_logs,release_end_at):
        deployment = Deployment(release_id, deploy_name, app_name, 1, "", command, container_port, host_port,
                                settings.IMAGE_REGISTRY_K8S_SECRET,release_logs,release_end_at)
        deployment_body = yaml.safe_load(render_jinja2_template('deployment.yaml', deployment=deployment))
        resp = self.v1apps.create_namespaced_deployment(namespace=self.namespace, body=deployment_body,
                                                        _request_timeout=K8S_CONNECTION_TIMEOUT)
        return resp

    def delete_deployment_by_name(self, name):
        resp = self.v1apps.delete_namespaced_deployment(namespace=self.namespace, name=name,
                                                         body=self.delete_options,
                                                         _request_timeout=K8S_CONNECTION_TIMEOUT)
        logger.info('Delete deployment controller %s successed!' % name)
        return resp

    def get_pods(self, label):
        return self.v1client.list_namespaced_pod(namespace=self.namespace, label_selector=dict_to_string(label),
                                                 _request_timeout=K8S_CONNECTION_TIMEOUT).items


def render_jinja2_template(template, **kwargs):
    env = Environment(loader=PackageLoader('deploy', 'conf'))
    # env.filters['format_misc_path'] = format_misc_path
    env.trim_blocks = True
    env.lstrip_blocks = True
    template = env.get_template(template)
    return template.render(kwargs)


def dict_to_string(label_dict, s=','):
    arr = [k + "=" + str(label_dict[k]) for k in label_dict]
    return s.join(arr)
