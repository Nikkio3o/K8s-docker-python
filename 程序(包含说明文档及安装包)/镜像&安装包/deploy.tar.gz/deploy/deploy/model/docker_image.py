# -*- coding: UTF-8 -*-
import docker
import logging
import os
import random
import shutil
import string
import time
from django.conf import settings
from git import Repo

logger = logging.getLogger('app')
DOCKER_FILE_PATH = '/tmp/kml-dockerfiles'


class Docker(object):
    def __init__(self, url=None):
        super(Docker, self).__init__()
        if not url:
            self.client = docker.from_env()
        else:
            self.client = docker.DockerClient(base_url=url, timeout=600)
        self.client.login(username=settings.IMAGE_REGISTRY_USER, password=settings.IMAGE_REGISTRY_PASSWORD,
                          registry=settings.IMAGE_REGISTRY_PROTOCOL + "://" + settings.IMAGE_REGISTRY_URL)

    def get_image(self, job_meta, project):
        self.job_meta = job_meta
        image_name = self._get_image(job_meta.image_name)
        base_image = image_name
        image_name = settings.IMAGE_REGISTRY_USER + "/deploy"
        image_name = self.create_image(image_name, base_image,
                                       project.git_ssh_address,
                                       job_meta.branch,
                                       tag="job-" + str(job_meta.release_id) + '-' + str(int(time.time())),
                                       workdir="")
        return image_name

    def _get_image(self, name):
        if not settings.USE_LOCAL_K8S and not settings.IMAGE_REGISTRY_URL:
            raise Exception(
                "don't config the docker image registry, please set 'IMAGE_REGISTRY_URL' in your config file. ")
        # if not settings.USE_LOCAL_K8S:
        #     name = "%s/%s" % (settings.IMAGE_REGISTRY_URL,name)

        existed = self.client.images.list(name)
        if not existed and not self.pull_image(name):
            raise Exception(
                "the image: %s doesn not exist, please input correct image name." % name)
        return name

    def pull_image(self, image_name):
        try:
            image = self.client.images.pull(image_name)
        except Exception as e:
            logger.error("fail to pull image:%s." % image_name)
            return False
        return True

    # 创建镜像
    def create_image(self, image_name, base_image, git_addr, git_branch, tag='latest',
                     workdir='/code'):
        image = image_name + ':' + tag
        docker_file = self.create_docker_file(base_image, workdir, git_addr, git_branch)
        image_id, result_stream = self.client.images.build(tag=image, path=docker_file)
        image_build_logs = ''
        for chunk in result_stream:
            print chunk
            image_build_logs = image_build_logs + chunk.get('stream', '')
        self.job_meta.docker_build_logs = image_build_logs
        self.job_meta.save(update_fields=['docker_build_logs'])
        print image_build_logs
        shutil.rmtree(docker_file)
        logger.info("successfully create images: %s, response is %s" %
                    (image, result_stream))
        # 上传镜像到私有仓库
        res = self.client.images.push(image_name, tag=tag)
        logger.info("push image:%s, result is:\n%s" % (image_name, res))
        return image

    def build_logs(self):
        self.client.info()

    def create_docker_file(self, base_image, workdir, git_addr, git_branch):
        store_dir = '/code'
        if not workdir.startswith('/'):
            workdir = '/code/' + workdir
        dockfile_path = "%s/job-%s-Dockerfile/" % (
            DOCKER_FILE_PATH, get_rand_string())
        if not os.path.exists(dockfile_path):
            os.makedirs(dockfile_path)
        docker_file = '%sDockerfile' % dockfile_path
        product = True
        self.prepare_git_product(git_addr, git_branch, dockfile_path)
        # 生成dockerfile文件
        content = "From %s\n" % base_image
        if product:
            content += "RUN mkdir -p /code \n"
            content += "ADD . /code \n"
            content += "WORKDIR %s \n" % workdir
        else:
            content += "WORKDIR %s \n" % workdir
        content += "CMD [\"sh\", \"-c\", \"tail -f /dev/null\"]"
        with open(docker_file, 'w') as file:
            file.write(content)
        return dockfile_path

    def prepare_git_product(self, url, branch, dest_dir):
        product_name = ''
        if url and branch:
            shutil.rmtree(dest_dir)
            code, commit_id, commit_message = git_clone(url, branch)
            shutil.copytree(code, dest_dir)
            shutil.rmtree(code)
        return product_name


def git_clone(url, branch):
    dir_name = _get_random_name(url, branch)
    local_path = '%s/%s' % (settings.GIT_CODE_PATH, dir_name)
    env = {}
    if hasattr(settings, 'GIT_SSH') and settings.GIT_SSH:
        env.update({'GIT_SSH': settings.GIT_SSH})
    if not os.path.exists(local_path):
        logging.info(Repo.clone_from(url=url, to_path=local_path, env=env))
    local_repo = Repo(local_path)
    with local_repo.git.custom_environment(GIT_SSH=env['GIT_SSH']):
        local_repo.git.fetch()
        # checkout branch or commit
        local_repo.git.checkout(branch)
        try:
            local_repo.git.merge('origin/' + branch)
        except Exception as e:
            logger.error(e)
    commit = local_repo.head.commit
    return (local_path, commit.name_rev, commit.message)


def _get_random_name(url, branch):
    project = url[url.rfind(':') + 1:url.rfind('.git')]
    ran_8_string = get_rand_string()
    return project.replace('/', '-') + ran_8_string


def get_rand_string(len=8):
    return ''.join(random.sample(string.ascii_letters + string.digits, 8))
