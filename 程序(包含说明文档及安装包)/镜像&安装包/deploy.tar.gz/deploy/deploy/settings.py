# SECURITY WARNING: don't run with debug turned on in production!
import os

DEPLOY_ENV = os.getenv('DEPLOY_ENV', 'LOCAL')

PRODUCTION = DEPLOY_ENV == 'PRODUCTION'

DEBUG = not PRODUCTION

#python3
print('use env: ' + DEPLOY_ENV)
os.umask(000)
module_name = 'deploy.%s' % DEPLOY_ENV.lower()
module = __import__(module_name, globals(), locals(), ['*'])
for k in dir(module):
    locals()[k] = getattr(module, k)

# if not os.path.exists(locals()['DOCKERFILE_PATH']):
#     os.makedirs(locals()['DOCKERFILE_PATH'], mode=0777)
ALLOWED_HOSTS = ['*']