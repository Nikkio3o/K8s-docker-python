# -*- coding: UTF-8 -*-

from django.shortcuts import render
from deploy.common import function,config
import json
import logging
import requests



def index(request) :
    context = {
        'count' : 3,
        'page' : config.page
    }
    return render(request, 'node/index.html', context)


def get_node_list(request) :


    list_service = [{"ip":"192.168.50.160","os":"Cenos7.1","status":"ready","node_type":"主节点"},
                    {"ip":"192.168.50.161","os":"Cenos7.1","status":"ready","node_type":"从节点"},
                    {"ip":"192.168.50.162","os":"Cenos7.1","status":"ready","node_type":"从节点"},]


    return function.ajax_return_exit('操作成功', 0, list_service)


