from .base import *
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': config.db['name'],
        'USER': config.db['user'],
        'PASSWORD': config.db['pwd'],
        'HOST': '172.16.234.12',
        'PORT': config.db['port'],
    }
}