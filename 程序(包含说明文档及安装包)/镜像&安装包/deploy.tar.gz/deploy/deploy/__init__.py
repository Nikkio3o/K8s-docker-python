# -*- coding: UTF-8 -*-
"""
setting中的配置默认为sqlite3数据库 当需要修改成MySql时
并且在setting.py的同级目录的__init__.py 加入如下配置
否则会报错： Error loading MySQLdb module.
"""
from __future__ import absolute_import

from .celery import app as celery_app  # noqa

import pymysql
pymysql.install_as_MySQLdb()


