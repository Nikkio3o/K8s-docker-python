# -*- coding: UTF-8 -*-

# ============================================================
# 上线单管理
# author    Devil
# blog      http://gong.gg/
# version   0.0.1
# datetime  2017-07-27
# ============================================================

from django.shortcuts import render
from django.views.decorators import csrf
from deploy.model.models import Project, Release, Cluster
from deploy.model.const import Status
import os, time
from deploy.common import function, config
from deploy.lib import git


def index(request):
    context = {
        'count': Release.objects.count(),
        'page': config.page
    }
    return render(request, 'release/index.html', context)


def saveinfo(request):
    project_list = Project.objects.all().order_by('-project_id').values('project_id', 'project_name')
    cluster_list = Cluster.objects.all().order_by('cluster_id').values('cluster_id', 'cluster_name')
    context = {
        'project_list': project_list,
        'cluster_list': cluster_list
    }
    return render(request, 'release/saveinfo.html', context)


def info(request):
    # 项目id
    release_id = request.POST.get('release_id', '')
    if len(release_id) > 0:
        # 获取项目数据
        data = Release.objects.filter(release_id=release_id).first()

    else:
        data = None

    dataStatus = {
        'status': data.status
    }
    return function.ajax_return_exit('操作成功', 0, dataStatus)



def get_release_list(request):
    keywords = request.POST.get('keywords', '')
    page = int(request.POST.get('page', 1)) - 1
    page_size = int(request.POST.get('page_size', config.page['page_size']))
    page_start = page * page_size
    data = Release.objects.filter(title__contains=keywords).all().order_by('-release_id').values('release_id',
                                                                                                 'project_id', 'title',
                                                                                                 'branch', 'version',
                                                                                                 'status','port',
                                                                                                 'create_time')[
           page_start:page_start + page_size]
    result = []
    if data != None:
        for items in data:
            # 获取项目信息
            project = Project.objects.filter(project_id=items['project_id']).first()
            if project != None:
                items['project_name'] = project.project_name
            else:
                items['project_name'] = ''

            # 状态操作按钮处理
            if items['status'] == Status.READY:
                items['is_release_show'] = True
                items['is_delete_show'] = True
                items['is_stop_show'] = False
            elif items['status'] == Status.RUNNING:
                items['is_release_show'] = False
                items['is_delete_show'] = False
                items['is_stop_show'] = True
                items['is_running_show'] = True
            elif items['status'] == Status.DESTROYED:
                items['is_release_show'] = True
                items['is_delete_show'] = True
                items['is_stop_show'] = False
            # 状态处理
            items['status_text'] = items['status']
            # 日期
            items['create_time'] = items['create_time'].strftime('%Y-%m-%d %H:%M');
            # 追加到列表中
            result.append(items);

    return function.ajax_return_exit('操作成功', 0, result)


def get_branch_list(request):
    # 项目id
    project_id = request.POST.get('project_id', '')
    if len(project_id) == 0:
        return function.ajax_return_exit('项目id不能为空', -1)

    # 获取项目数据
    data = Project.objects.filter(project_id=project_id).first()
    if data != None:
        # 获取项目名称
        git_dir_address = function.get_git_address(function.get_project_handle_temp_dir(), data.git_ssh_address,
                                                   data.git_alias)

        if os.path.exists(git_dir_address) == False:
            return function.ajax_return_exit('项目路径地址不存在', -2)

        # 同步远程分支
        ret = git.fetch(git_dir_address)
        if ret != True:
            return function.json_exit(ret)

        # 获取版本列表
        return function.json_exit(git.get_branch(git_dir_address, '-a'))
    else:
        return function.ajax_return_exit('没有找到相关的项目', -3)


def get_version_list(request):
    # 项目id
    project_id = request.POST.get('project_id', '')
    if len(project_id) == 0:
        return function.ajax_return_exit('项目id不能为空', -1)

    # 分支名称
    branch = request.POST.get('branch')
    if len(branch) == 0:
        return function.ajax_return_exit('请选择项目分支', -2)

    # 获取项目数据
    data = Project.objects.filter(project_id=project_id).first()
    if data != None:
        # 获取项目名称
        git_dir_address = function.get_git_address(function.get_project_handle_temp_dir(), data.git_ssh_address,
                                                   data.git_alias)
        if os.path.exists(git_dir_address) == False:
            return function.ajax_return_exit('项目路径地址不存在', -1)

        # 清除当前项目改动项
        ret = git.clean(git_dir_address)
        if ret != True:
            return function.json_exit(ret)

        # 拉取远程分支最新代码
        ret = git.fetch(git_dir_address, branch)
        if ret != True:
            return function.json_exit(ret)

        # 分支切换
        ret = git.checkout(git_dir_address, branch)
        if ret != True:
            return function.json_exit(ret)

        # 拉取分支最新代码到本地分支
        ret = git.pull(git_dir_address, branch)
        if ret != True:
            return function.json_exit(ret)

        # 获取版本列表
        return function.json_exit(git.log(git_dir_address, 30))
    else:
        return function.ajax_return_exit('没有找到相关的项目', -3)


def save(request):
    # 数据添加
    Release(
        project_id=request.POST['project_id'],
        cluster_id=request.POST['cluster_id'],
        title=request.POST['title'],
        branch=request.POST['branch'],
        exec_command=request.POST['exec_command'],
        port=request.POST['port'],
        status=request.POST.get('status', Status.READY)
    ).save()

    # 返回数据
    return function.ajax_return_exit('操作成功')


def release_delete(request):
    release_id = request.POST.get('release_id', '0')
    if release_id == '0':
        return function.ajax_return_exit('参数错误', -1)
    Release.objects.filter(release_id=release_id).delete()

    # 返回数据
    return function.ajax_return_exit('删除成功')


def handle_release(request):
    # 参数校验
    project_id = request.POST.get('project_id', '0')
    release_id = request.POST.get('release_id', '0')
    handle_type = int(request.POST.get('handle_type', 1))
    release = Release.objects.filter(release_id=release_id).first()

    if handle_type == 1:
        release.start()
    else:
        release.stop()
    # 返回数据
    return function.ajax_return_exit('正在部署')


def release_logs(request):
    release_id = request.POST.get('release_id', '0')
    release = Release.objects.filter(release_id=release_id).first()
    result = []
    result.append(release.docker_build_logs)
    result.append(release.k8s_logs)
    return function.ajax_return_exit('操作成功', 0, result)
