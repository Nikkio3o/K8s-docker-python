# -*- coding: utf-8 -*-
import pytz
from datetime import datetime


def get_pod_instance(pod_list):
    pod_instance_list = []
    for pod in pod_list:
        # assert False, pod
        if isinstance(pod, dict):
            instance = {
                "pod_name": pod['metadata']['name'],
                "pod_ip": (pod['status']).get('podIP', ''),
                "host": "%s/%s" % ((pod['spec']).get('nodeName', ''), (pod['status']).get('hostIP', '')),
                "phase": get_pod_container_status(pod['status']),
                "last_phase": get_pod_container_status(pod['status'], 'lastState', 'finishedAt'),
                "containers": get_container(pod['status']['containerStatuses']) if pod['status'].has_key(
                    'containerStatuses') else '',
                "start_time": (pod['status']).get('startTime', ''),
                "namespace": pod['metadata']['namespace']
            }
        else:
            instance = {
                "pod_name": pod.metadata.name,
                "pod_ip": pod.status.pod_ip,
                "host": "%s/%s" % (pod.spec.node_name, pod.status.host_ip),
                "phase": get_pod_container_status_py(pod.status),
                "last_phase": get_pod_container_status_py(pod.status, 'last_state', 'finished_at'),
                "containers": get_container(pod.status.container_statuses),
                "start_time": pod.status.start_time,
                "namespace": pod.metadata.namespace
            }
        pod_instance_list.append(instance)
    return pod_instance_list


def get_pod_container_status(pod_status, option='state', param='startedAt'):
    phase = {}
    if option == 'state':
        phase['status'] = pod_status['phase']
    for condition in pod_status['conditions'] if pod_status.has_key('conditions') else []:
        if condition['type'] == 'PodScheduled' and condition['status'] == 'False':
            phase['reason'] = condition['reason']
            return phase
        else:
            break
    container_statuses = pod_status[
        'containerStatuses'] if pod_status.has_key('containerStatuses') else []
    for index, container_status in enumerate(container_statuses):
        for key, values in container_status[option].items():
            if key == 'running':
                phase['timestamp'] = utc_to_local(
                    values[param]) if values.has_key(param) else ''
            else:
                phase['timestamp'] = utc_to_local(
                    values[param]) if values.has_key(param) else ''
                phase['reason'] = values[
                    'reason'] if values.has_key('reason') else ''
    return phase


def get_pod_container_status(pod_status, option='state', param='startedAt'):
    phase = {}
    if option == 'state':
        phase['status'] = pod_status['phase']
    for condition in pod_status['conditions'] if pod_status.has_key('conditions') else []:
        if condition['type'] == 'PodScheduled' and condition['status'] == 'False':
            phase['reason'] = condition['reason']
            return phase
        else:
            break
    container_statuses = pod_status[
        'containerStatuses'] if pod_status.has_key('containerStatuses') else []
    for index, container_status in enumerate(container_statuses):
        for key, values in container_status[option].items():
            if key == 'running':
                phase['timestamp'] = utc_to_local(
                    values[param]) if values.has_key(param) else ''
            else:
                phase['timestamp'] = utc_to_local(
                    values[param]) if values.has_key(param) else ''
                phase['reason'] = values[
                    'reason'] if values.has_key('reason') else ''
    return phase


def get_container(container_statuses):
    containers = []
    if container_statuses:
        for container_dict in container_statuses:
            if not isinstance(container_dict, dict):
                container_dict = container_dict.to_dict()
            containers.append({
                "name": container_dict['name'],
                "image": container_dict['image'],
                # "container_id": container_dict['container_id'] if container_dict.has_key('container_id') else container_dict['containerID'],
            })
    return containers


def get_pod_container_status_py(pod_status, option='state', param='started_at'):
    phase = {}
    if option == 'state':
        phase['status'] = pod_status.phase
    for condition in pod_status.conditions if has_effect_attr(pod_status, 'conditions') else []:
        if condition.type == 'PodScheduled' and condition.status == 'False':
            phase['reason'] = condition.reason
            return phase
        else:
            break
    for index, container_status in enumerate(pod_status.container_statuses) if has_effect_attr(pod_status,
                                                                                               'container_statuses') else []:
        for key, value in getattr(container_status, option).__dict__.items() if has_effect_attr(container_status,
                                                                                                option) else {}.items():
            if key.startswith('__'):
                continue
            if key == '_running' and value is not None:
                phase['timestamp'] = utc_to_local(
                    getattr(value, param)) if has_effect_attr(value, param) else ''
            elif value is not None:
                phase['timestamp'] = utc_to_local(
                    getattr(value, param)) if has_effect_attr(value, param) else ''
                phase['reason'] = value.reason if has_effect_attr(
                    value, 'reason') else ''
    return phase


def utc_to_local(utc_time, utc_format='%Y-%m-%dT%H:%M:%SZ'):
    utc_dt = utc_time
    local_tz = pytz.timezone('Asia/Shanghai')
    local_format = "%Y-%m-%d %H:%M:%S"
    if not isinstance(utc_time, datetime):
        utc_dt = datetime.strptime(utc_time, utc_format)
    local_dt = utc_dt.replace(tzinfo=pytz.utc).astimezone(local_tz)
    time_str = local_dt.strftime(local_format)
    return time_str


def has_effect_attr(obj, attr):
    return getattr(obj, attr) is not None if hasattr(obj, attr) else False
