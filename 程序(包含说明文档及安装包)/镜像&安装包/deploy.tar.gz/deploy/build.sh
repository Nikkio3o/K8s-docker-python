#!/usr/bin/env bash
docker build -t 192.168.56.80:8888/deploy/deploy-service:latest .
docker push 192.168.56.80:8888/deploy/deploy-service:latest

