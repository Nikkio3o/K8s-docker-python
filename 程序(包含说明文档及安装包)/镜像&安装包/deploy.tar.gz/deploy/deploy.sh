pip install virtualenv
virtualenv venv --python=python2.7
. venv/bin/activate
pip install -r requirements.txt
export DEPLOY_ENV=docker
python manage.py runserver 0.0.0.0:8009



