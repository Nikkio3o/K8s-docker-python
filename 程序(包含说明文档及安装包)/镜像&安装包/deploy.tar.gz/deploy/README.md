# 安装说明
## 1.安装python2.7环境(网上有略)
## 2.下载依赖 
```shell script
 pip install -r requirements.txt
```
## 3.配置基础环境和相关配置
### 安装redis && mysql
### mysql配置
在deploy/common/config.py里面配置数据库地址、用户、密码
 ```python
db = {
    'name' : 'deploy',
    'user' : 'root',
    'pwd'  : 'hanghang',
    'host' : 'localhost',
    'port' : 3306
}
 ```
### docker仓库配置
去https://hub.docker.com/ 网站注册一个账户
在deploy/base.py里配置
```python
IMAGE_REGISTRY_URL = "index.docker.io"
IMAGE_REGISTRY_USER = "你的用户"
IMAGE_REGISTRY_PASSWORD = "你的密码"
IMAGE_REGISTRY_PROTOCOL = "https"
IMAGE_REGISTRY_K8S_SECRET = "registry-secret"
```
### 配置从git拉取GIT_SSH秘钥脚本
在deploy/base.py里配置
```python
GIT_SSH = '/Users/momo/.ssh/id_ssh.sh'
```
id_ssh.sh具体内容
```shell script
ssh -i /Users/hanghang/.ssh/id_rsa  -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no $*
```
 /Users/hanghang/.ssh/id_rsa 为私钥地址,切记这个文件的权限为744
 ### 配置拉取临时项目的地址
 在deploy/base.py里配置
```python
GIT_CODE_PATH = '/tmp/deploy/source-code'
```
/tmp/deploy/source-code 这个路径是拉取git项目的临时保持的地址

### 配置celery 
在deploy/base.py里配置
```python
BROKER_URL = 'redis://localhost:6379/3'
CELERY_RESULT_BACKEND = 'redis://localhost:6379/3'
```
redis://localhost:6379/3 这个是对应的地址和对应的库号

## 4.创建数据库和对应表
### a.先去自己的mysql中创建deploy数据库
### b.在项目根目录输入一下命令创建对应表
```shell script
 python manage.py migrate
```

## 5.启动服务
### a.启动celery,在项目根目录执行
```shell script
sh ./bin/run_celery.sh
```
注意里换成对应BROKER_URL
### b.启动flower,在项目根目录执行(非必要这个只是方便看异步执行的任务状态)
```shell script
sh ./bin/run_flower.sh
```
注意里换成对应BROKER_URL
### c.最后启动Django服务,在项目根目录执行
```shell script
sh ./bin/run_service.sh
```



