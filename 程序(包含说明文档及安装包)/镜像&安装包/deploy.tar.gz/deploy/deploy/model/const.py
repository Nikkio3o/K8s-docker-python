# -*- coding: utf-8 -*-


class Status:
    EDITING = 'editing'
    READY = 'ready'
    STARTING = 'starting'
    RUNNING = 'running'
    SUCCESS = 'success'
    FAIL = 'failed'
    STOP = 'stop'
    IGNORED = 'ignored'
    PENDING = 'pending'
    IMAGEBUILDING = 'imageBuilding'
    TERMINATED = 'terminated'
    DESTROYED = 'destroyed'
    Depressed = 'depressed'


STATUS_CHOICES = [(v, v)
                  for k, v in Status.__dict__.items() if not k.startswith('__')]